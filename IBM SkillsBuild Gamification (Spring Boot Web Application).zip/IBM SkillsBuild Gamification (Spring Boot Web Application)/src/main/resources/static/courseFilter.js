const courses = {
    "Artificial Intelligence": "../img/AI.png",
    "Capstone": "../img/Capstone.png",
    "Data Science": "../img/Data Science.png",
    "IBM Cloud": "../img/IBM Cloud.png",
    "IBM Engineering": "../img/IBM Engineering.png",
    "IBM Security": "../img/IBM Security.png",
    "IBM Z": "../img/IBM Z.png",
    "Apply to IBM": "../img/apply.png",
    "Quantum Computing": "../img/Quantum.png",
    "Professional Badges": "../img/digital credentials.png"
};

// Loop through each course card and insert images
document.querySelectorAll(".card").forEach(card => {
    const courseNameElement = card.querySelector(".course-name");
    const courseName = courseNameElement.textContent.trim();

    if (courses[courseName]) {
        let imageDiv = document.createElement("div");
        let img = document.createElement("img");
        img.src = courses[courseName];
        img.alt = courseName;

        if (courseName === "Professional Badges" || courseName === "Apply to IBM") {
            imageDiv.classList.add("unique-image");
            img.classList.add("unique-img"); // Identify "Professional Badges" image
            courseNameElement.style.paddingTop = "10px";
        }

        else {
            imageDiv.classList.add("course-image");
        }

        imageDiv.appendChild(img);
        card.insertBefore(imageDiv, courseNameElement);
    }
});

// Function to sync "Professional Badges" image size with "Artificial Intelligence" (after CSS is applied)
function resizeUniqueImage() {
    const referenceImg = document.querySelector(".course-image img"); // AI Image
    const uniqueImg = document.querySelectorAll(".unique-img"); // Professional Badges Image
    uniqueImg.forEach(unique => {
        if(referenceImg && unique){
            const computedStyle = window.getComputedStyle(referenceImg);
            unique.style.width = computedStyle.width;
            unique.style.height = computedStyle.height;


        }
    })




}

// Run after CSS is applied
window.addEventListener("load", resizeUniqueImage);
window.addEventListener("resize", resizeUniqueImage);
