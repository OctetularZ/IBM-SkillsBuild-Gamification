document.addEventListener("DOMContentLoaded", function () {
    const hamburgerBtn = document.getElementById("hamburger-btn");
    const filterSidebar = document.getElementById("filter-sidebar");

    // Open/Close sidebar
    hamburgerBtn.addEventListener("click", function () {
        const isActive = filterSidebar.classList.toggle("active"); // Toggle 'active' class
        hamburgerBtn.innerText = isActive ? "x" : "Filter"; // Sync text with state
    });
});