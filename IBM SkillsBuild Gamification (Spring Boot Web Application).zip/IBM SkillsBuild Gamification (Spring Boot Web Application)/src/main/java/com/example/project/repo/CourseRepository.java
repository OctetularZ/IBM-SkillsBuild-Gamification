package com.example.project.repo;

import com.example.project.domain.Course;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface CourseRepository extends CrudRepository<Course, Integer> {
    public Course findByCourseName(String name);
    public Optional<Course> findByCourseId(int id);
    public List<Course> findAll();
}
