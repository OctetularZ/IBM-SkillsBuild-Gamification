package com.example.project.repo;

import com.example.project.domain.Takes;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface TakesRepository extends CrudRepository<Takes, Integer> {
    public List<Takes> findByUserId(long Id);
    public Takes findByUserIdAndCourseCourseId(long Id, int course_id);
    public List<Takes> findByUserIdAndFinished(long Id, boolean finished);
}
