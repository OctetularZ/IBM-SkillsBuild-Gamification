package com.example.project.domain;

import com.example.project.repo.ReviewsRepository;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;

@Entity
public class Reviews {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String courseName;
    private String username;
    private int rating;
    private String comment;

    public Long getid() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public int getRating() {
        return rating;
    }
    public List<Long> getAllRating(ReviewsRepository reviewsRepository) {
        List<Reviews> allReviews = reviewsRepository.findAll();

        // Create a list of (ID, Rating) pairs
        List<Map.Entry<Long, Integer>> ratingEntries = new ArrayList<>();
        for (Reviews review : allReviews) {
            ratingEntries.add(new AbstractMap.SimpleEntry<>(review.getid(), review.getRating()));
        }

        // Sort based on ratings in descending order
        ratingEntries.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
        System.out.println("W: " + ratingEntries);
        // Collect the top 3 review IDs
        List<Long> top3 = new ArrayList<>();
        for (int i = 0; i < Math.min(3, ratingEntries.size()); i++) {
            top3.add(ratingEntries.get(i).getKey()); // Get the ID
        }

        return top3;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
