package com.example.project.repo;

import com.example.project.domain.Reviews;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ReviewsRepository extends CrudRepository<Reviews, Long> {
    public Reviews findById(int courseId);
    public List<Reviews> findByCourseName(String courseName);
    public List<Reviews> findByRating(int rating);
    public List<Reviews> findAll();
}
