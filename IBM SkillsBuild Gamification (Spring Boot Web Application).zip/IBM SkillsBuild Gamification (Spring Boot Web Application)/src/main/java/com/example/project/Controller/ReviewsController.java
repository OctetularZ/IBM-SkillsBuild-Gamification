package com.example.project.Controller;

import com.example.project.domain.Course;
import com.example.project.domain.Reviews;
import com.example.project.repo.CourseRepository;
import com.example.project.repo.ReviewsRepository;
import com.example.project.repo.UserRepository;
import com.example.project.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class ReviewsController {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private ReviewsRepository reviewsRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    public UserService userService;


    @GetMapping(value = "/addReview" )
    public String addReviews(Model model,@RequestParam("courseName") String courseName) {
        userService.setCurrentReviewCourseName(courseName);
        return "addReview";
    }

    @RequestMapping(value = "/showReviews")
    public String showReviews(@ModelAttribute Reviews reviews, Model model) {
        reviews.setUsername(userService.getLoggedInUser().getUsername());
        reviews.setCourseName(userService.getCurrentReviewCourseName());


        reviewsRepository.save(reviews);

        model.addAttribute("reviews", reviewsRepository.findByCourseName(reviews.getCourseName()));
        return "showReviews";
    }
}
