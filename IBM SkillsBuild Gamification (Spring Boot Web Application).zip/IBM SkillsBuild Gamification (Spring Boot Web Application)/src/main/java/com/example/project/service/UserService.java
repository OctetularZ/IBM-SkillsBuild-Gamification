package com.example.project.service;

import com.example.project.domain.User;
import com.example.project.repo.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {



    @Autowired
    private HttpSession session;

    @Autowired
    private  UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public String getCurrentReviewCourseName() {
        return currentReviewCourseName;
    }

    public void setCurrentReviewCourseName(String currentReviewCourseName) {
        this.currentReviewCourseName = currentReviewCourseName;
    }

    private String currentReviewCourseName = "";

    private boolean error = false;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public UserRepository getUserRepository() {
        return userRepository;
    }

    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    public void setLoggedInUser(String username) {
        User user = userRepository.findByUsername(username).orElse(null);
        session.setAttribute("loggedInUser", user);
    }
    public User getLoggedInUser() {
        return (User) session.getAttribute("loggedInUser");
    }
    public boolean getError() {
        return error;
    }

    public void setError(boolean error) {
        this.error = error;
    }
    public boolean registerUser(String username, String password, String role) {
        User user = new User();
        if(userRepository.findByUsername(username).isEmpty()) {
            user.setUsername(username);
            user.setPassword(passwordEncoder.encode(password));
            user.setRole(role);
            userRepository.save(user);
            return true;


        }
        return false;

    }

    // Method to update user details if username matches
    public boolean updateUser(String existingUser, String username, String newPassword, String newRole) {
        Optional<User> userOptional = userRepository.findByUsername(existingUser);
        if (userOptional.isPresent()) {

            User user = userOptional.get();

            if (newPassword != null && !newPassword.isEmpty()) {
                user.setPassword(passwordEncoder.encode(newPassword));
            }
            if (username != null && !username.isEmpty()) {
                user.setUsername(username);
            }

            if (newRole != null && !newRole.isEmpty()) {
                user.setRole(newRole);
            }


            userRepository.save(user);
            return true;
        }

        return false; // User not found
    }
    public boolean loginUser(String username, String password) {
        Optional<User> optionalUser = userRepository.findByUsername(username);
        if (optionalUser.isPresent()) {
            User storedUser = optionalUser.get();
            // Successfully logged in
            return passwordEncoder.matches(password, storedUser.getPassword());
        }
        return false;
    }
}
