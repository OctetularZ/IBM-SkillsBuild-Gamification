package com.example.project.Controller;

import com.example.project.domain.Course;
import com.example.project.domain.Takes;
import com.example.project.domain.User;
import com.example.project.repo.CourseRepository;
import com.example.project.repo.TakesRepository;
import com.example.project.repo.UserRepository;
import com.example.project.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


@Controller
public class StartCourseController {
    @Autowired
    private TakesRepository tRepo;
    @Autowired
    private UserRepository uRepo;
    @Autowired
    private CourseRepository cCrepo;
    @Autowired
    private UserService userService;
    @RequestMapping("/courses")
    public String index(Model model) {
        if(userService.getLoggedInUser() == null){
            return "redirect:/";
        }
        Optional<User> user = uRepo.findByUsername(userService.getLoggedInUser().getUsername());

        if(user.isPresent()) {
            Long id = user.get().getId();
            List<Takes> currentRelations = tRepo.findByUserId(id);
            List<Course> courses = currentRelations.stream().map(Takes:: getCourse).toList();

            List<Takes> finishedRelations = tRepo.findByUserIdAndFinished(id, true);
            List<Course> finishedCourses = finishedRelations.stream().map(Takes :: getCourse).collect(Collectors.toList());

            List<Course> allCourses = cCrepo.findAll();
            model.addAttribute("relations", currentRelations);
            model.addAttribute("allCourses", allCourses);

            model.addAttribute("completedCourses", finishedCourses.size());
            return "index";


        }

        return "home";



    }
    @GetMapping("/startCourse/{courseId}")
    public String courseStart(@PathVariable int courseId, Model model) {
        if(userService.getLoggedInUser() == null){
            return "redirect:/";
        }
        // Get currently logged-in user
        Optional<User> userOptional = uRepo.findByUsername(userService.getLoggedInUser().getUsername());

        if (userOptional.isPresent()) {
            User thisUser = userOptional.get(); // Unwrap Optional<User>

            Course thisCourse = cCrepo.findByCourseId(courseId)
                    .orElseThrow(() -> new RuntimeException("Course not found!"));

            Takes takes = new Takes(thisCourse, thisUser); // Pass actual User object
            tRepo.save(takes);
        }

        return "redirect:/courses";
    }

    @GetMapping("/resumeCourse/{courseId}")
    public String courseResume(@PathVariable int courseId, Model model) {

        Course thisCourse = cCrepo.findByCourseId(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found!"));

        return "redirect:/courses"; // + thisCourse.getLink();
    }

}