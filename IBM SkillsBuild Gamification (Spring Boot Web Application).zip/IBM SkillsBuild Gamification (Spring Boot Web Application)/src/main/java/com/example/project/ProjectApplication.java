package com.example.project;


import com.example.project.domain.Course;
import com.example.project.domain.Reviews;
import com.example.project.domain.SearchAndFilterCourses;
import com.example.project.domain.User;
import com.example.project.repo.CourseRepository;
import com.example.project.repo.ReviewsRepository;
import com.example.project.repo.UserRepository;
import com.example.project.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Map;

@SpringBootApplication
public class ProjectApplication implements ApplicationRunner {

    @Autowired
    private CourseRepository cRepo;

    @Autowired
    private UserRepository uRepo;

    @Autowired
    private UserService userService;

    @Autowired
    private ReviewsRepository reviewsRepository;
    public static void main(String[] args) { SpringApplication.run(ProjectApplication.class, args); }
    public void run(ApplicationArguments args) throws Exception {
        SearchAndFilterCourses searchAndFilterCourses = new SearchAndFilterCourses();

        // adding courses to repo, may not be necessary after merging.
        for (Map.Entry<String, String> entry : searchAndFilterCourses.getCourseLinks().entrySet()) {
            cRepo.save(new Course(entry.getKey(), entry.getValue()));
        }

        userService.registerUser("Foo", "1234", "ADMIN");

        Reviews dummyReviews = new Reviews();
        Reviews dummyReviews2 = new Reviews();
        Reviews dummyReviews3 = new Reviews();
        Reviews dummyReviews4 = new Reviews();


        dummyReviews.setComment("WWW");
        dummyReviews.setCourseName("Artificial Intelligence");
        dummyReviews.setRating(3);
        dummyReviews.setUsername("user");
        reviewsRepository.save(dummyReviews);


        dummyReviews2.setComment("WWW");
        dummyReviews2.setCourseName("Capstone");
        dummyReviews2.setRating(2);
        dummyReviews2.setUsername("user");

        reviewsRepository.save(dummyReviews2);

        dummyReviews3.setComment("WWW");
        dummyReviews3.setCourseName("Data Science");
        dummyReviews3.setRating(1);
        dummyReviews3.setUsername("user");

        reviewsRepository.save(dummyReviews3);

        dummyReviews4.setComment("WWW");
        dummyReviews4.setCourseName("IBM Cloud");
        dummyReviews4.setRating(5);
        dummyReviews4.setUsername("user");

        reviewsRepository.save(dummyReviews4);








    }

}