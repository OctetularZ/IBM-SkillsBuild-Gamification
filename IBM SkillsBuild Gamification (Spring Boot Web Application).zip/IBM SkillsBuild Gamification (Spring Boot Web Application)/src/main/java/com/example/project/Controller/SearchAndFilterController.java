package com.example.project.Controller;

import com.example.project.domain.Reviews;
import com.example.project.domain.SearchAndFilterCourses;
import com.example.project.repo.ReviewsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
public class SearchAndFilterController {
    private final SearchAndFilterCourses searchAndFilterCourses = new SearchAndFilterCourses();
    private List<String> fullCourses = searchAndFilterCourses.getCourses();
    @Autowired
    ReviewsRepository reviewsRepository;

    // GET method to display the search and filter form
    @GetMapping("/coursesForm")
    public String index(Model model) {
        model.addAttribute("fullCourses", fullCourses);
        model.addAttribute("hyperlinks", searchAndFilterCourses.getCourseLinks());

        return "courses/coursesForm"; // Show the form
    }

    // POST method to handle filtering courses
    @PostMapping("/filterCourses")
    public String filterCourses(
            @RequestParam(value = "beginner", required = false) String beginner,
            @RequestParam(value = "intermediate", required = false) String intermediate,
            @RequestParam(value = "advanced", required = false) String advanced,
            @RequestParam(value = "top3", required = false) String top3,
            @RequestParam(value = "fullCourse", required = false) String fullCourseAvailable,
            Model model
    ) {
        model.addAttribute("hyperlinks", searchAndFilterCourses.getCourseLinks());

        List<String> filteredCourses = new ArrayList<>();
        //only adding the course wanted
        if (beginner != null) {
            filteredCourses.addAll(searchAndFilterCourses.getBeginnerCourses());
        }
        if (intermediate != null) {
            filteredCourses.addAll(searchAndFilterCourses.getIntermediateCourses());
        }
        if (advanced != null) {
            filteredCourses.addAll(searchAndFilterCourses.getAdvancedCourses());
        }
        if(top3 !=null){
            Reviews reviews = new Reviews();
            List<String> top3Courses = new ArrayList<>();
            for(Long rating : reviews.getAllRating(reviewsRepository)){
                Optional<Reviews> currentReview = reviewsRepository.findById(rating);
                currentReview.ifPresent(value -> top3Courses.add(value.getCourseName()));
            }
            System.out.println("top3Courses");
            System.out.println(top3Courses);
            filteredCourses = top3Courses;

        }
        if (fullCourseAvailable != null || filteredCourses.isEmpty()) {
            filteredCourses = fullCourses; // Show all courses if nothing is selected
        }

        model.addAttribute("fullCourses", filteredCourses);
        return "courses/coursesForm";
    }

    // POST method to handle searching for courses
    @PostMapping("/showCourse")
    public String showCourses(@RequestParam(value = "search", required = false) String course, Model model) {
        if (course == null || course.isBlank()) {
            model.addAttribute("courseExists", false);
            model.addAttribute("courses", fullCourses);
            model.addAttribute("courseSearched", "");
        } else {
            // getting the courses that matches the user input
            List<String> matchedCourses = searchAndFilterCourses.courseExists(course);
            if (!matchedCourses.isEmpty()) {

                model.addAttribute("courses", matchedCourses);
                model.addAttribute("courseExists", true);
            } else {
                model.addAttribute("courseExists", false);


            }
            model.addAttribute("courseSearched", course);
        }

        return "courses/coursesList"; // Display results
    }
}

// Steve
