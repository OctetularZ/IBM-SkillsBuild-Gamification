package com.example.project.Controller;

import com.example.project.domain.User;
import com.example.project.repo.UserRepository;
import com.example.project.service.UserDetails;
import com.example.project.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
public class LoginRegisterController {

    @Autowired
    private UserService userService;

    @RequestMapping("/courseChecklist")
    public String checklist() {
        return "courseChecklist";
    }

    @GetMapping(value = "/register")
    public String registerGet() {
        return "register";
    }

    @PostMapping(value = "/register")
    public String registerPost(@ModelAttribute User user, Model model) {
        if(!userService.registerUser(user.getUsername(), user.getPassword(), user.getRole())) {
            model.addAttribute("error", "Username is taken, choose another");
            return "register";
        }
        return "redirect:/login";
    }

    @GetMapping(value = "/login")
    public String loginGet(Model model) {
        if(userService.getError()){

            model.addAttribute("error", "Invalid username or password");

        }
        return "login";
    }
    @GetMapping(value = "/logout")
    public String logoutGet(Model model) {

        model.addAttribute("logOut", true);


        return "home";
    }
    @PostMapping(value = "/loggingIn")
    public String login(@ModelAttribute User user, Model model) {
        // Handle login logic

        if(userService.loginUser(user.getUsername(), user.getPassword())){
            userService.setLoggedInUser(user.getUsername());
            model.addAttribute("username", user.getUsername());
            userService.setError(false);
            return "home";
        }
        userService.setError(true);

        return "redirect:/login";  // Redirect to login page if authentication fails
    }


}
