package com.example.project.Controller;

import com.example.project.domain.Takes;
import com.example.project.domain.User;
import com.example.project.repo.TakesRepository;
import com.example.project.repo.UserRepository;
import com.example.project.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


@Controller
public class CourseCompleteController {
    @Autowired
    private TakesRepository tRepo;
    @Autowired
    private UserRepository uRepo;
    @Autowired
    private UserService userService;
    @GetMapping("/finishCourse/{courseId}")
    public String finishCourse(Model model, @PathVariable int courseId) {

        // Retrieve the currently logged-in user
        User loggedInUser = userService.getLoggedInUser();
        if (loggedInUser == null) {
            return "redirect:/login"; // Redirect if the user is not logged in
        }

        // Fetch the Takes relationship for the logged-in user and course
        Takes thisRelation = tRepo.findByUserIdAndCourseCourseId(loggedInUser.getId(), courseId);
        if (thisRelation == null) {
            return "redirect:/courses?error=notEnrolled"; // Handle case where user is not enrolled
        }

        // Mark the course as finished
        thisRelation.markFinished();
        tRepo.save(thisRelation);

        // Update the user's completed courses count
        loggedInUser.addCoursesComplete();
        uRepo.save(loggedInUser);

        return "redirect:/courses";
    }

}
