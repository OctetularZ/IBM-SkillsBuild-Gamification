package com.example.project.domain;

import java.util.*;
import java.util.stream.Collectors;

public class SearchAndFilterCourses {

    private String username = "";
    //list of available courses
    private final List<String> courses = List.of(
            "Artificial Intelligence", "Capstone", "Data Science", "IBM Cloud",
            "IBM Engineering", "IBM Security", "IBM Z", "Professional Badges", "Quantum Computing", "Apply to IBM"
    );
    // course matched to there difficulty level.
    private static final Map<String, List<String>> courseLevels = Map.of(
            "Beginner", List.of("Apply to IBM", "IBM Cloud", "Professional Badges"),
            "Intermediate", List.of("Capstone", "IBM Security", "Data Science", "IBM Engineering"),
            "Advanced", List.of("IBM Z", "Artificial Intelligence", "Quantum Computing")
    );

    //return list depending on difficulty level
    public List<String> getBeginnerCourses() {
        return courseLevels.get("Beginner");
    }

    public List<String> getIntermediateCourses() {
        return courseLevels.get("Intermediate");
    }

    public List<String> getAdvancedCourses() {
        return courseLevels.get("Advanced");
    }




    //checking for a match in the coursers and returning the course that match
    public List<String> courseExists(String keyword){
        return !getFullMatchCourse(keyword).isEmpty() ? getFullMatchCourse(keyword)
                : !getPartialMatchCourses(keyword).isEmpty() ? getPartialMatchCourses(keyword)
                : Collections.emptyList();

    }

    //returns courses that match exactly as inputted
    public List<String> getFullMatchCourse(String keyword) {
        return courses.stream()
                .filter(course -> course.equalsIgnoreCase(keyword))
                .collect(Collectors.toList());
    }
    //get the course that partially match it
    public List<String> getPartialMatchCourses(String keyword) {
        List<String> keywordWords = Arrays.asList(keyword.toLowerCase().split(" "));

        return courses.stream()
                .filter(course -> Arrays.stream(course.toLowerCase().split(" "))
                        .anyMatch(keywordWords::contains))
                .collect(Collectors.toList());
    }


    public List<String> getCourses() {
        return Collections.unmodifiableList(courses);
    }
    public String getUsername() {
        return username;
    }

    //returns the hyperlinks of each course
    public Map<String, String> getCourseLinks() {
        final String baseLink = "https://academic.ibm.com/a2mt/downloads/";
        Map<String, String> hyperLinks = new HashMap<String,String>();
        for(String course: courses){
            switch (course){
                case "Professional Badges":
                    hyperLinks.put("Professional Badges", "https://skillsbuild.org/students/digital-credentials");
                    break;
                case "Apply to IBM":
                     hyperLinks.put("Apply to IBM", "https://www.ibm.com/uk-en/careers/career-opportunities");
                     break;
                default:
                    hyperLinks.put(course, baseLink + course.toLowerCase().replace(" ", "_"));
            }


        }
        return hyperLinks;

    }


}
