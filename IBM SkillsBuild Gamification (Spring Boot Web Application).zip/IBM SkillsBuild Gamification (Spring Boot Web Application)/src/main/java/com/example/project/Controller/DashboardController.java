package com.example.project.Controller;

import com.example.project.ProjectApplication;
import com.example.project.domain.User;
import com.example.project.repo.UserRepository;
import com.example.project.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.Objects;
import java.util.Optional;
@Controller
public class DashboardController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    public UserService userService;

    // This method handles GET requests for the home page (showing the login form)
    @GetMapping(value = "/")
    public String homePage(Model model) {
        if(userService.getLoggedInUser() != null){
            model.addAttribute("username", userService.getLoggedInUser().getUsername());
        }

        // Return the home page or a login form view
        return "home";  // Display the home page or login form
    }

    // This method handles POST requests for the home page (processing login data)

}
