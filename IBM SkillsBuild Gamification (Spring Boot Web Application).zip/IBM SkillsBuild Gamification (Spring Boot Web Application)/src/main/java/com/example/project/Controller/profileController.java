package com.example.project.Controller;

import com.example.project.domain.User;
import com.example.project.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class profileController {
    @Autowired
    private UserService userService;



    @GetMapping ("/change-personal-info")
    public String changePersonalInfo(Model model) {

        return "userMan/change-personal-info";
    }

    @PostMapping ("/update-personal-info")
    public String updateUser(@ModelAttribute User user, Model model) {
        if(userService.updateUser(userService.getLoggedInUser().getUsername(), user.getUsername(),user.getPassword(), "USER")){
            userService.setLoggedInUser(user.getUsername());
            model.addAttribute("username", user.getUsername());
            return "home";
        }


        return "redirect:/change-personal-info";
    }

}
