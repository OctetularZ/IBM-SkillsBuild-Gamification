package com.example.project.Controller;

import com.example.project.domain.User;
import com.example.project.repo.UserRepository;
import com.example.project.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
public class LeaderboardController {
    @Autowired
    private UserRepository uRepo;

    @Autowired
    private UserService userService;

    @RequestMapping("/leaderboard")
    public String leaderboard(Model model) {
        List<User> users = uRepo.findAll();

        // Sort users in descending order based on completed courses
        users.sort((o1, o2) -> Integer.compare(o2.getCoursesComplete(), o1.getCoursesComplete()));

        // Get the currently logged-in user
        User loggedInUser = userService.getLoggedInUser();
        if(loggedInUser == null) {
            return "redirect:/";

        }

        model.addAttribute("loggedInUser", loggedInUser);
        model.addAttribute("sortedUsers", users);

        return "leaderboard";
    }
}
